<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>WEBSITE INFORMATION ABOUT NOVEL</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy this line! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <!-- Static navbar -->
    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="">Operations</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="post.php">Data</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="logout.php">Logout</a></li>
          </ul>
          


    <div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <br>
        
      
        <h1>WEBSITE INFORMATION ABOUT NOVEL</h1>
        <br>
         Novel karya anak bangsa tidak kalah menariknya dengan novel dari mancanegara, banyak sekalai karya anak muda indonesia yang menginspirasi bahkan sampai diangkat ke film layar lebar.<br>
         novel adalah suatu karya sastra berbentuk prosa naratif yang panjang, dimana di dalamnya terdapat rangkaian cerita tentang kehidupan seorang tokoh dan orang-orang di sekitarnya dengan menonjolkan sifat dan watak dari setiap tokoh dalam novel tersebut.

        Ada juga yang mengatakan bahwa pengertian novel adalah suatu karangan berbentuk prosa yang di dalamnya terdapat unsur intrinsik dan unsur ekstrinsik. Tidak seperti cerpen (cerita pendek), isi cerita sebuah novel jauh lebih panjang dan kompleks, serta terdapat pesan tersembunyi yang ingin disampaikan kepada pembacanya.<br>
        <p></p>
        <p></p>
        <p>
         
        </p>
      </div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
  </body>
</html>
