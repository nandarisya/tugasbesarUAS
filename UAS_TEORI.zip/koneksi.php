<?php
$conn=mysqli_connect("sql303.epizy.com","epiz_23899029","RgAdCfZV5qSN","epiz_23899029_crudd");
?>

